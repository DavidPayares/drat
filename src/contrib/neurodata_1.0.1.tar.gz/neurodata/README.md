## `NeuroData` repository for `Neuronorm`!

This repository contains example data to test the [`NeuroNorm`](https://github.com/DavidPayares/neuronorm) package.

## Installation

You can install all the packages in this repo by using `devtools`.

``` r
# install.packages("devtools")
devtools::install_github("DavidPayares/neurodata")
```
