extern int v3p_netlib_dsconv_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *ritz,
  v3p_netlib_doublereal *bounds,
  v3p_netlib_doublereal *tol,
  v3p_netlib_integer *nconv
  );
