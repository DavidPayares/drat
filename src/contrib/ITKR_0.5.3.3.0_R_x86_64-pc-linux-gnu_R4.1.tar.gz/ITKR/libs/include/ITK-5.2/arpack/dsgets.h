extern int v3p_netlib_dsgets_(
  v3p_netlib_integer *ishift,
  char *which,
  v3p_netlib_integer *kev,
  v3p_netlib_integer *np,
  v3p_netlib_doublereal *ritz,
  v3p_netlib_doublereal *bounds,
  v3p_netlib_doublereal *shifts,
  v3p_netlib_ftnlen which_len
  );
