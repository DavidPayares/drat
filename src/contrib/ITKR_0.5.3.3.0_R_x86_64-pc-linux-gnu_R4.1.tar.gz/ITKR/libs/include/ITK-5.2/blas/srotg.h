extern int v3p_netlib_srotg_(
  v3p_netlib_real *sa,
  v3p_netlib_real *sb,
  v3p_netlib_real *c__,
  v3p_netlib_real *s
  );
