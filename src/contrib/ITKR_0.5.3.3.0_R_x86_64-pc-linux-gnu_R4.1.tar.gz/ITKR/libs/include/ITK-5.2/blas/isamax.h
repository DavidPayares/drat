extern v3p_netlib_integer v3p_netlib_isamax_(
  v3p_netlib_integer *n,
  v3p_netlib_real *sx,
  v3p_netlib_integer *incx
  );
