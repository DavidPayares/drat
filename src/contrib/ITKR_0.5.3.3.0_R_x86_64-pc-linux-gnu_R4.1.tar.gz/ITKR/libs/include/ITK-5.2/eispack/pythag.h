extern v3p_netlib_doublereal v3p_netlib_pythag_(
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *b
  );
