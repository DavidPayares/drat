extern v3p_netlib_Z_f v3p_netlib_zdotu_(
  v3p_netlib_doublecomplex * ret_val,
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *zx,
  v3p_netlib_integer *incx,
  v3p_netlib_doublecomplex *zy,
  v3p_netlib_integer *incy
  );
