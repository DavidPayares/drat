extern v3p_netlib_doublereal v3p_netlib_sdot_(
  v3p_netlib_integer *n,
  v3p_netlib_real *sx,
  v3p_netlib_integer *incx,
  v3p_netlib_real *sy,
  v3p_netlib_integer *incy
  );
